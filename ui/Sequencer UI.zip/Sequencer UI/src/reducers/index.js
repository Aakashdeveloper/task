import { combineReducers } from 'redux';
import sequencer from './sequencer'

const rootReducer = combineReducers({
    sequencer
})

export default rootReducer;