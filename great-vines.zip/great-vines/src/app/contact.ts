export interface Contact {
  FirstName: string;
  LastName: string;
  Name: string;
  Email: string;
  MailingCity: string;
}
