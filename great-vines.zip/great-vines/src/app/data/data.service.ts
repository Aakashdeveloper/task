import { Injectable } from '@angular/core';
import { Contact } from '../contact';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';

@Injectable()
export class DataService {

  // path for salesforce call
  path = '/services/data/v37.0/sobjects/Contact';
  // Base query
  query = '/services/data/v37.0/query?q=SELECT + FirstName, LastName, Name, Email, MailingCity + from + Contact';

  constructor(private http: HttpClient, private auth: AuthService) { }


  // making get request on api
  getData(): Observable<Contact[]> {
    return this.http.get<Contact[]>(`${this.auth.getInstanceUrl()}${this.query}`, {
      headers: {
        authorization: `Bearer ${this.auth.getAccessToken()}`
      }
    }).pipe((
      map(res => res['records'])
    ));
  }

  // making post call to add data
  addContact(data) {
    console.log(data, '-------');
    return this.http.post(`${this.auth.getInstanceUrl()}${this.path}`, data, {
      headers: {
        'Authorization': `Bearer ${this.auth.getAccessToken()}`,
        'Content-Type': 'application/json'
      }
    }).pipe(
      catchError(data)
    );
  }
}
