import { Component } from '@angular/core';
import { DataService } from '../data/data.service';
import { Contact } from '../contact';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';
import { ContactDialogComponent } from '../contact-dialog/contact-dialog.component';
import { MatDialog } from '@angular/material';

import { AuthService } from '../auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {
  constructor(public auth: AuthService, public dialog: MatDialog, private dataService: DataService) {
  }

  displayedColumns = ['FirstName', 'LastName', 'Email', 'MailingCity'];
  dataSource = new ContactDataSource(this.dataService);

  openDialog(): void {
    const dialogRef = this.dialog.open(ContactDialogComponent, {
      width: '600px',
      data: 'Add Contact'
    });

    dialogRef.componentInstance.event.subscribe((result) => {
      this.dataService.addContact(result.data)
        .subscribe(contact => {
          this.dataSource = new ContactDataSource(this.dataService);
        });
    });
  }
}

export class ContactDataSource extends DataSource<any> {
  constructor(private dataService: DataService) {
    super();
  }

  connect(): Observable<Contact[]> {
    return this.dataService.getData();
  }

  disconnect() {
  }
}
