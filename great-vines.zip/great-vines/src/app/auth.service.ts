import { Router } from '@angular/router';
import { Injectable } from '@angular/core';


// Url for authentication
const baseUrl       = 'http://login.salesforce.com';
const authorizeUrl  = '/services/oauth2/authorize';
const tokenUrl      = '/services/oauth2/token';

declare var Qs: any;
(window as any).global = window;
@Injectable()
export class AuthService {

  // Adding sales forces client_id, token
  /*
    add redirect url in cros of sales force dashboard
    and then run the app
  */
  salesforce = {
    client_id: '3MVG9yZ.WNe6byQDn_tc_.9aCjm_xoITkY9Wk9TX1us_oY_8ImbWF6cUgmkrRWmL4xlitLBRQgGA9pupDi.76',
    response_type: 'token',
    redirect_uri: 'http://localhost:3000',
    scopes: 'api id'
  };

  refreshToken: string;
  accessToken: string;
  instanceUrl: string;
  issuedAt: number;

  constructor(public router: Router) {}

  public login(): void {
    this.router.ngOnDestroy();
    window.location.href = this.authUrl();
  }

  public handleAuthentication(): void {
    this.parseHash((err, authResult) => {
      console.log(authResult);
      if (authResult && authResult.accessToken) {
        window.location.hash = '';
        this.accessToken = authResult.accessToken;
        this.instanceUrl = authResult.instanceUrl;
        this.issuedAt = authResult.issuedAt;
        this.router.navigate(['/dashboard']);
      } else if (err) {
        this.router.navigate(['/']);
        console.log(err);
      }
    });
  }

  public logout(): void {
    this.accessToken = null;
    this.instanceUrl = null;
    this.issuedAt = null;
    this.router.navigate(['/']);
  }

  public isAuthenticated(): boolean {
    return Date.now() < (this.issuedAt + 86400000);
  }

  public getInstanceUrl() {
    return this.instanceUrl;
  }

  public getAccessToken() {
    return this.accessToken;
  }

  private authUrl() {
    return `${baseUrl}${authorizeUrl}?${this.params()}`;
  }

  private params() {
    let str = '';
    for (const key in this.salesforce) {
      if (this.salesforce.hasOwnProperty(key)) {
        str += `${key}=${encodeURIComponent(this.salesforce[key])}&`;
      }
    }
    return str.substring(0, str.length - 1);
  }

  private parseHash(cb) {
    let hash: any;

    let hashStr = window.location.hash;
    hashStr = hashStr.replace(/^#?\/?/, '');

    hash = Qs.parse(hashStr);

    if (hash.hasOwnProperty('error')) {
      return cb(hash.error);
    }

    if (
      !hash.hasOwnProperty('access_token') &&
      !hash.hasOwnProperty('id_token') &&
      !hash.hasOwnProperty('refresh_token')
    ) {
      return cb(null, null);
    }

    return cb(null, {
      accessToken: hash.access_token || null,
      idToken: hash.id || null,
      refreshToken: hash.refresh_token || null,
      issuedAt: hash.issued_at || null,
      tokenType: hash.token_type || null,
      scope: hash.scope || null,
      signature: hash.signature || null,
      instanceUrl: hash.instance_url || null,
    });
  }
}
